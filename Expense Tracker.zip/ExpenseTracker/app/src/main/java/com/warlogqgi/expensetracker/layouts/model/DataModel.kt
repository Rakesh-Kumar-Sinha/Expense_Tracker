package com.warlogqgi.expensetracker.layouts.model

data class DataModel(
    val id:String,
    val category: String?=null,
    val desc: String?=null,
    val expamount:String?=null,
    val date: String?=null,
    val time:String?=null

)



