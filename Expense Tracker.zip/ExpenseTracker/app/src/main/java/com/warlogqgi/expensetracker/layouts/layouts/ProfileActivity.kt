package com.warlogqgi.expensetracker.layouts.layouts

import android.annotation.SuppressLint
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.warlogqgi.expensetracker.R
import de.hdodenhof.circleimageview.CircleImageView

class ProfileActivity : AppCompatActivity() {

    lateinit var profImage : CircleImageView
    lateinit var backBtn :ImageView
    lateinit var name : TextView
    lateinit var phone:TextView
    lateinit var location:TextView
    lateinit var email:TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        // Finding Ids
        profImage = findViewById(R.id.viewProfImage)
        backBtn= findViewById(R.id.backBtnProfile)
        name = findViewById(R.id.viewProfName)
        phone = findViewById(R.id.viewProfPhone)
        location = findViewById(R.id.viewProfLocation)
        email = findViewById(R.id.viewProfEmail)





    }
}